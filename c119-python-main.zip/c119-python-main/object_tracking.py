


# Carrega o vídeo


# Verifica se o vídeo foi aberto corretamente

# Leitura do primeiro frame


# Seleciona a região de interesse (ROI) para rastrear


# Inicializa o rastreador


while True:
    # Lê o próximo frame do vídeo
    ret, frame = cap.read()
    if not ret:
        break

    # Atualiza o rastreador com o próximo frame
    ret, bbox = tracker.update(frame)

    # Converte as coordenadas da bounding box em inteiros
    bbox = tuple(map(int, bbox))

    # Desenha a bounding box no frame
    if ret:
        cv2.rectangle(frame, bbox, (0, 255, 0), 2)
    else:
        cv2.putText(frame, "Objeto perdido", (100, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2)

    # Mostra o frame atual com a bounding box
    

    # Sai do loop se a tecla 'q' for pressionada
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Libera o vídeo e fecha a janela
cap.release()
cv2.destroyAllWindows()
